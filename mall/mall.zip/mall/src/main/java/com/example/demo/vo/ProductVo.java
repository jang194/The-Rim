package com.example.demo.vo;

import lombok.Data;

@Data
public class ProductVo {
	private int no,price,halin,su,bprice,btime,juk,pansu;
	private String pcode,pimg,cimg,title,color,size,wriday;
}
