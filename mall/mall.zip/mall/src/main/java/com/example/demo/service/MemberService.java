package com.example.demo.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.example.demo.vo.MemberVo;

public interface MemberService {

	public String member();

	public String memberOk(MemberVo mvo);

	public int useridChk(HttpServletRequest request);

	public String login();

	public String loginOk(HttpSession session,MemberVo mvo);

	public String logout(HttpSession session);

}
