package com.example.demo.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.vo.MemberVo;

@Mapper
public interface MemberMapper {
	
	public void memberOk(MemberVo mvo);
	public int useridChk(String userid);
	public MemberVo loginOk(MemberVo mvo);

}
