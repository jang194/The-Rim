package com.example.demo.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.example.demo.mapper.MemberMapper;
import com.example.demo.vo.MemberVo;

@Service
@Qualifier("ms")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberMapper mapper;
	
	@Override
	public String member() {
		
		return "/member/member";
	}

	@Override
	public String memberOk(MemberVo mvo) {
		mapper.memberOk(mvo);
		return "redirect:/member/login";
	}

	@Override
	public int useridChk(HttpServletRequest request) {
		String userid = request.getParameter("userid");
		return mapper.useridChk(userid);
		
	}

	@Override
	public String login() {
		return "/member/login";
	}

	@Override
	public String loginOk(HttpSession session,MemberVo mvo) {
		
		mvo = mapper.loginOk(mvo);
		if(mvo==null)
		{
			return "redirect:/member/login";
		}
		else
		{
			session.setAttribute("userid", mvo.getUserid());
			session.setAttribute("name", mvo.getName());
		return "redirect:/main/main";
		}
	}

	@Override
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/main/main";
	}

}
