package com.example.demo.admin;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.vo.DaeVo;
import com.example.demo.vo.JungVo;
import com.example.demo.vo.ProductVo;

@Mapper
public interface AdminMapper {
	
	public ArrayList<DaeVo> getDae();
	public ArrayList<JungVo> getJung(String daecode);
	public int getPcode(String pcode); 
	public void productAddOk(ProductVo pvo);
}
