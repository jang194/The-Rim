package com.example.demo.vo;

import lombok.Data;

@Data
public class JungVo {

	private int no;
	private String name,code,daecode;
}
