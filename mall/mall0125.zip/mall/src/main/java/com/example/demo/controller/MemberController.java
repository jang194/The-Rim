package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.service.MemberService;
import com.example.demo.vo.MemberVo;

@Controller
public class MemberController {
	
	@Autowired
	@Qualifier("ms")
	private MemberService service;
	
	@RequestMapping("/member/member")
	public String member()
	{
		return service.member();
	}
	
	@RequestMapping("/member/memberOk")
	public String memberOk(MemberVo mvo)
	{
		return service.memberOk(mvo);
	}
	
	@RequestMapping("/member/useridChk")
	public @ResponseBody int useridChk(HttpServletRequest request)
	{
		return service.useridChk(request);
	}
	
	@RequestMapping("/member/login")
	public String login() 
	{
		return service.login();
	}
	
	@RequestMapping("/member/loginOk")
	public String loginOk(HttpSession session,MemberVo mvo)
	{
		return service.loginOk(session,mvo);
	}
	
	@RequestMapping("/member/logout")
	public String logout(HttpSession session)
	{
		return service.logout(session);
	}
	
}
