package com.example.demo.vo;

import lombok.Data;

@Data
public class DaeVo {
	
	private int no;
	private String name,code;

}
