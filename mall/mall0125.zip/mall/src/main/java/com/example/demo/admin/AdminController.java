package com.example.demo.admin;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.vo.DaeVo;
import com.example.demo.vo.JungVo;
import com.example.demo.vo.ProductVo;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@Controller
public class AdminController {

	@Autowired
	private AdminMapper mapper;
	
	@RequestMapping("/admin/productAdd")
	public String productAdd(Model model)
	{
		ArrayList<DaeVo> dlist = mapper.getDae();
		model.addAttribute("dlist", dlist);
		
		return "/admin/productAdd";
	}
	
	@RequestMapping("/admin/getJung")
	public @ResponseBody String getJung(HttpServletRequest request)
	{
		String daecode = request.getParameter("daecode");
		ArrayList<JungVo> jlist = mapper.getJung(daecode);
		String jung = "<option value=''>선택</option>";
		for(int i=0;i<jlist.size();i++)
		{
			JungVo jvo = jlist.get(i);
			jung = jung+"<option value='"+jvo.getCode()+"'>"+jvo.getName()+"</option>";
		}
		return jung;
		
	}
	
	@RequestMapping("/admin/getPcode")
	public @ResponseBody String getPcode(HttpServletRequest request)
	{
		String pcode = request.getParameter("pcode");
		int val = mapper.getPcode(pcode);
		String imsi = String.format("%03d", val); //val값을 3자리수로 만들고 부족한거 0으로 채워라
		
		return imsi;
	}
	
	@RequestMapping("/admin/productAddOk")
	public String productAddOk(HttpServletRequest request) throws Exception
	{
		String path = ResourceUtils.getFile("classpath:static/product").toPath().toString();
		int sizes=1024*1024*100;
		MultipartRequest multi=new MultipartRequest(request,path,sizes,"utf-8",new DefaultFileRenamePolicy());
		
		String[] imsi = multi.getParameterValues("size");
    	String size = "";
		for(int i=0;i<imsi.length;i++)
		{
			size = size+imsi[i]+",";
		}
		//0,1,2 
		String[] imsi2 = multi.getParameterValues("color");
		String color = "";
		for(int i=0;i<imsi2.length;i++)
		{
			color = color+imsi2[i]+",";
		}
		
		
		ProductVo pvo = new ProductVo();
		pvo.setSize(size);
		pvo.setColor(color);
		pvo.setPcode(multi.getParameter("pcode"));
		pvo.setPimg(multi.getFilesystemName("pimg"));
		pvo.setCimg(multi.getFilesystemName("cimg"));
		pvo.setTitle(multi.getParameter("title"));
		//pvo.setSize(size);
		//pvo.setColor(color);
		pvo.setPrice(Integer.parseInt(multi.getParameter("price")));
		pvo.setHalin(Integer.parseInt(multi.getParameter("halin")));
		pvo.setSu(Integer.parseInt(multi.getParameter("su")));
		pvo.setBprice(Integer.parseInt(multi.getParameter("bprice")));
		pvo.setBtime(Integer.parseInt(multi.getParameter("btime")));
		pvo.setJuk(Integer.parseInt(multi.getParameter("juk")));
//		pvo.setPansu(Integer.parseInt(multi.getParameter("pansu")));
//		pvo.setNo(Integer.parseInt(multi.getParameter("no")));
		
		mapper.productAddOk(pvo);
		return "redirect:/admin/productList";
		
	
		
	}

	
	
	
}
